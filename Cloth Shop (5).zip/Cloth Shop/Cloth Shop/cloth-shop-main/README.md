Create a .env file 

NODE_ENV = development
PORT = 5000
MONGO_URI = your mongodb uri
JWT_SECRET = 'abc123'
PAYPAL_CLIENT_ID = your paypal client id





npm install
cd frontend
npm install

 Run frontend  & backend 
npm run dev

Run backend only
npm run server


