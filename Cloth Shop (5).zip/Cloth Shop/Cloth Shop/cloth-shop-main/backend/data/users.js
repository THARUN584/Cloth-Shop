import bcrypt from "bcrypt";

const users = [
  {
    name: "Admin User",
    email: "admin@example.com",
    password: bcrypt.hashSync("123456", 10),
    isAdmin: true,
  },
  {
    name: "Jp",
    email: "jp@ele.com",
    password: bcrypt.hashSync("123456", 10),
  },
  {
    name: "giri",
    email: "giri@ple.com",
    password: bcrypt.hashSync("123456", 10),
  },
];

export default users;
